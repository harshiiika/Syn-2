document.addEventListener('DOMContentLoaded', function () {
  const sidebar = document.querySelector('.sidebar') || document.querySelector('#sidebar') || document.querySelector('#admin') || document.querySelector('#right');
  
  let isCollapsed = false;

  sidebar.style.transition = 'width 0.5s ease';
  sidebar.style.overflow = 'hidden';
  sidebar.style.width = '300px';

  const menuItems = sidebar.querySelectorAll('li, a, .nav-item');
  menuItems.forEach(item => {
    item.style.whiteSpace = 'nowrap';
  });

  toggleBtn.addEventListener('click', function () {
    console.log('Toggle button clicked! Current state:', isCollapsed ? 'collapsed' : 'expanded');

    if (isCollapsed) {
      sidebar.style.width = '25%';
      admin.style.visibility ='visible';
      right.style.width = '100%';
    } else {
      sidebar.style.width = '40px';
      admin.style.visibility ='hidden';
      right.style.width = '100%'; 
    }

    isCollapsed = !isCollapsed; 
  });
});


const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))


const myModal = document.getElementById('exampleModal');
const myInput = document.getElementById('file');

myModal.addEventListener('shown.bs.modal', () => {
  myInput.focus();
});



document.querySelector('#file').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        console.log('File selected:', file.name);
        
        setTimeout(() => {
            showUploadToast('success', 'File uploaded successfully!');
        }, 1000);
    }
});    