const correctEmail = "synthesisbikaner@gmail.com";
const correctPassword = "synthesis@2024";

function validateLogin(){
const Email = document.getElementById("email").value;
const Password = document.getElementById("password").value;


if (Email === correctEmail && Password === correctPassword) {
    window.location.href= "../admin/admin.html";
    return false;
}
else {
    alert("Invalid Credentials");
}
}

